import socket
import threading
import queue

HOST = '172.20.10.3'
PORT = 12345

# Thread-safe queue to store incoming tasks as (conn, task) tuples
task_queue = queue.Queue()

# Store client connections for sending results
connections = set()
connections_lock = threading.Lock()

def client_handler(conn, addr):
    print(f"[+] Connected by {addr}")
    with connections_lock:
        connections.add(conn)
    try:
        while True:
            data = conn.recv(1024).decode()
            if not data:
                break
            print(f"[RECEIVED TASK] From {addr}: {data}")
            # Add (conn, task) tuple to the central queue
            task_queue.put((conn, data))
    except Exception as e:
        print(f"[ERROR] {addr}: {e}")
    finally:
        with connections_lock:
            connections.discard(conn)
        conn.close()
        print(f"[-] Disconnected {addr}")

def task_worker():
    while True:
        conn, task = task_queue.get()  # Blocks until a task is available
        print(f"[PROCESSING TASK] {task}")
        
        # Simulate processing (for example, reverse the string)
        result = task[::-1]

        try:
            conn.sendall(result.encode())
        except Exception as e:
            print(f"[ERROR sending result] {e}")
        task_queue.task_done()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()
    print(f"[*] Server started on {HOST}:{PORT}")

    # Start the worker thread to process tasks sequentially
    worker_thread = threading.Thread(target=task_worker, daemon=True)
    worker_thread.start()

    while True:
        conn, addr = server.accept()
        threading.Thread(target=client_handler, args=(conn, addr), daemon=True).start()

if __name__ == '__main__':
    start_server()
