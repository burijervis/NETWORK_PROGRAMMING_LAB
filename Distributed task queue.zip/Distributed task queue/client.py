import socket

SERVER_IP = '172.20.10.3'  # Server IP address
PORT = 12345


def start_client():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((SERVER_IP, PORT))

    try:
        while True:
            task = input("Enter a task (or 'exit' to quit): ")
            if task.lower() == 'exit':
                break
            client.sendall(task.encode())
            result = client.recv(1024).decode()
            print(f"Result: {result}")
    finally:
        client.close()


if __name__ == '__main__':
    start_client()
